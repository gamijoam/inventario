import React, { useState, useEffect, useCallback } from 'react';
import { Plus, X, Search, Minus } from 'lucide-react';
import apiClient from '../../../config/axios';
import { toast } from 'react-hot-toast';
import { formatCurrency } from '../../../utils/currency';

const QuickItemForm = ({ isOpen, onClose, onSubmit, technicians = [], loading = false }) => {
    const [isManual, setIsManual] = useState(false);
    const [quantity, setQuantity] = useState(1);
    const [searchTerm, setSearchTerm] = useState('');
    const [products, setProducts] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [description, setDescription] = useState('');
    const [unitPrice, setUnitPrice] = useState(0);
    const [technicianId, setTechnicianId] = useState('');

    // Buscar productos
    useEffect(() => {
        if (searchTerm.length > 2 && !isManual) {
            const timeoutId = setTimeout(async () => {
                try {
                    const res = await apiClient.get(`/products/?search=${searchTerm}`);
                    setProducts(res.data || []);
                } catch (error) {
                    console.error('Error searching products:', error);
                }
            }, 500);
            return () => clearTimeout(timeoutId);
        } else {
            setProducts([]);
        }
    }, [searchTerm, isManual]);

    const handleSelectProduct = (product) => {
        setSelectedProduct(product);
        setUnitPrice(product.price || 0);
        setSearchTerm('');
        setProducts([]);
    };

    const validateForm = useCallback(() => {
        if (isManual) {
            if (!description.trim()) {
                toast.error('Describa el servicio');
                return false;
            }
            if (!technicianId) {
                toast.error('Seleccione un técnico para servicio manual');
                return false;
            }
        } else {
            if (!selectedProduct) {
                toast.error('Seleccione un producto');
                return false;
            }
        }

        if (quantity <= 0) {
            toast.error('Cantidad debe ser mayor a 0');
            return false;
        }

        if (unitPrice <= 0) {
            toast.error('Precio debe ser mayor a 0');
            return false;
        }

        return true;
    }, [isManual, selectedProduct, description, technicianId, quantity, unitPrice]);

    const handleSubmit = async () => {
        if (!validateForm()) return;

        const itemData = {
            product_id: selectedProduct?.id || null,
            description: selectedProduct?.name || description,
            quantity,
            unit_price: unitPrice,
            technician_id: technicianId ? parseInt(technicianId) : null,
            observations: '',
        };

        try {
            await onSubmit(itemData);
            // Reset form
            setIsManual(false);
            setQuantity(1);
            setSearchTerm('');
            setSelectedProduct(null);
            setDescription('');
            setUnitPrice(0);
            setTechnicianId('');
            onClose();
        } catch (error) {
            console.error('Error submitting item:', error);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4">
            <div className="bg-white rounded-t-2xl md:rounded-2xl shadow-2xl max-w-2xl w-full md:max-h-[90vh] overflow-y-auto">
                {/* Header */}
                <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 flex items-center justify-between rounded-t-2xl">
                    <h2 className="text-2xl font-bold">Agregar Ítem</h2>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-blue-500 rounded-lg transition-colors"
                    >
                        <X size={24} />
                    </button>
                </div>

                {/* Content */}
                <div className="p-6 space-y-6">
                    {/* Tabs */}
                    <div className="flex gap-2 border-b border-slate-200">
                        <button
                            onClick={() => {
                                setIsManual(false);
                                setSearchTerm('');
                                setSelectedProduct(null);
                            }}
                            className={`pb-3 px-4 font-semibold transition-colors ${
                                !isManual
                                    ? 'text-blue-600 border-b-2 border-blue-600'
                                    : 'text-slate-500 hover:text-slate-700'
                            }`}
                        >
                            📦 Repuesto del Inventario
                        </button>
                        <button
                            onClick={() => {
                                setIsManual(true);
                                setSelectedProduct(null);
                            }}
                            className={`pb-3 px-4 font-semibold transition-colors ${
                                isManual
                                    ? 'text-blue-600 border-b-2 border-blue-600'
                                    : 'text-slate-500 hover:text-slate-700'
                            }`}
                        >
                            🔨 Servicio Manual
                        </button>
                    </div>

                    {/* Búsqueda o descripción */}
                    {!isManual ? (
                        <>
                            {!selectedProduct ? (
                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-sm font-semibold text-slate-700 mb-2">
                                            Buscar repuesto
                                        </label>
                                        <div className="relative">
                                            <Search className="absolute left-3 top-3 text-slate-400" size={18} />
                                            <input
                                                autoFocus
                                                type="text"
                                                placeholder="Batería, Pantalla, Cable..."
                                                value={searchTerm}
                                                onChange={(e) => setSearchTerm(e.target.value)}
                                                className="w-full pl-10 pr-4 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                                            />
                                        </div>

                                        {products.length > 0 && (
                                            <div className="mt-3 max-h-64 overflow-y-auto space-y-2">
                                                {products.map(product => (
                                                    <button
                                                        key={product.id}
                                                        onClick={() => handleSelectProduct(product)}
                                                        className="w-full p-3 bg-slate-50 hover:bg-blue-50 rounded-lg border border-slate-200 hover:border-blue-400 transition-all text-left"
                                                    >
                                                        <div className="font-semibold text-slate-800">{product.name}</div>
                                                        <div className="flex justify-between items-center mt-1">
                                                            <span className="text-sm text-slate-600">{formatCurrency(product.price)}</span>
                                                            <span className="text-xs text-slate-500">Stock: {product.stock}</span>
                                                        </div>
                                                    </button>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ) : (
                                <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                                    <p className="font-semibold text-blue-900 mb-2">✓ Producto seleccionado</p>
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-bold text-slate-800">{selectedProduct.name}</p>
                                            <p className="text-sm text-slate-600">{formatCurrency(selectedProduct.price)}</p>
                                        </div>
                                        <button
                                            onClick={() => setSelectedProduct(null)}
                                            className="text-red-600 hover:text-red-700 font-semibold text-sm"
                                        >
                                            Cambiar
                                        </button>
                                    </div>
                                </div>
                            )}
                        </>
                    ) : (
                        <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-2">
                                Descripción del servicio *
                            </label>
                            <input
                                autoFocus
                                type="text"
                                placeholder="Ej: Instalación de batería, Limpieza interna..."
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                className="w-full px-4 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                            />
                        </div>
                    )}

                    {/* Cantidad, Precio, Técnico */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-2">Cantidad</label>
                            <div className="flex items-center gap-2">
                                <button
                                    onClick={() => setQuantity(Math.max(0.5, quantity - 0.5))}
                                    className="p-2 bg-slate-200 hover:bg-slate-300 rounded-lg transition-colors"
                                >
                                    <Minus size={16} />
                                </button>
                                <input
                                    type="number"
                                    min="0.1"
                                    step="0.5"
                                    value={quantity}
                                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 1)}
                                    className="flex-1 px-3 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-center font-semibold"
                                />
                                <button
                                    onClick={() => setQuantity(quantity + 0.5)}
                                    className="p-2 bg-slate-200 hover:bg-slate-300 rounded-lg transition-colors"
                                >
                                    <Plus size={16} />
                                </button>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-2">Precio unitario</label>
                            <input
                                type="number"
                                step="0.01"
                                value={unitPrice}
                                onChange={(e) => setUnitPrice(parseFloat(e.target.value) || 0)}
                                readOnly={selectedProduct && !isManual}
                                className={`w-full px-3 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-semibold ${
                                    selectedProduct && !isManual ? 'bg-slate-100 text-slate-500' : ''
                                }`}
                                placeholder="0.00"
                            />
                        </div>

                        {isManual && (
                            <div>
                                <label className="block text-sm font-semibold text-slate-700 mb-2">Técnico *</label>
                                <select
                                    value={technicianId}
                                    onChange={(e) => setTechnicianId(e.target.value)}
                                    className="w-full px-3 py-2 border-2 border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                                >
                                    <option value="">Seleccionar...</option>
                                    {technicians.map(tech => (
                                        <option key={tech.id} value={tech.id}>
                                            {tech.username || tech.name}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        )}
                    </div>

                    {/* Subtotal */}
                    <div className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                            <span className="font-semibold text-slate-700">Subtotal:</span>
                            <span className="text-2xl font-bold text-slate-800">
                                {formatCurrency(quantity * unitPrice)}
                            </span>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="bg-slate-50 border-t border-slate-200 p-6 flex gap-3 justify-end rounded-b-2xl sticky bottom-0">
                    <button
                        onClick={onClose}
                        className="px-6 py-3 border-2 border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-100 transition-colors"
                    >
                        Cancelar
                    </button>
                    <button
                        onClick={handleSubmit}
                        disabled={loading}
                        className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2 transition-colors"
                    >
                        {loading ? '⏳ Agregando...' : (
                            <>
                                <Plus size={18} /> Agregar ítem
                            </>
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default QuickItemForm;
