import React from 'react';
import { CreditCard, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { formatCurrency } from '../../../utils/currency';

const PaymentTimeline = ({ payments = [], orderTotal = 0, onAddPayment }) => {
    if (!payments.length && orderTotal === 0) {
        return null;
    }

    const totalPaid = payments.reduce((acc, p) => acc + parseFloat(p.amount), 0);
    const pending = Math.max(0, orderTotal - totalPaid);
    const paymentPercentage = orderTotal > 0 ? (totalPaid / orderTotal) * 100 : 0;

    // Determinar estado
    let status = 'unpaid';
    if (totalPaid >= orderTotal && orderTotal > 0) {
        status = 'paid';
    } else if (totalPaid > 0) {
        status = 'partial';
    }

    // Formatear fecha y hora
    const formatDateTime = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        return date.toLocaleDateString('es-ES', {
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <CreditCard size={20} className="text-blue-600" />
                    Historial de Pagos
                </h3>
                {orderTotal > 0 && status !== 'paid' && (
                    <button
                        onClick={onAddPayment}
                        className="text-sm font-semibold text-blue-600 hover:text-blue-700 px-3 py-1 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                    >
                        + Agregar abono
                    </button>
                )}
            </div>

            {/* Resumen */}
            <div className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Total de la orden:</span>
                    <span className="font-bold text-slate-800">{formatCurrency(orderTotal)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Total pagado:</span>
                    <span className="font-bold text-emerald-600">{formatCurrency(totalPaid)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Pendiente:</span>
                    <span className={`font-bold ${pending > 0 ? 'text-amber-600' : 'text-emerald-600'}`}>
                        {formatCurrency(pending)}
                    </span>
                </div>

                {/* Barra de progreso */}
                {orderTotal > 0 && (
                    <div className="mt-3 pt-3 border-t border-slate-200">
                        <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Progreso de pago</span>
                            <span className="text-xs font-bold text-slate-700">{Math.round(paymentPercentage)}%</span>
                        </div>
                        <div className="w-full bg-slate-300 rounded-full h-2.5">
                            <div
                                className={`h-2.5 rounded-full transition-all ${
                                    status === 'paid'
                                        ? 'bg-emerald-500'
                                        : status === 'partial'
                                            ? 'bg-amber-400'
                                            : 'bg-slate-400'
                                }`}
                                style={{ width: `${Math.min(100, paymentPercentage)}%` }}
                            />
                        </div>
                    </div>
                )}
            </div>

            {/* Estado badge */}
            {status === 'paid' && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center gap-2">
                    <CheckCircle size={18} className="text-emerald-600 flex-shrink-0" />
                    <span className="text-sm font-semibold text-emerald-700">Orden completamente pagada</span>
                </div>
            )}

            {status === 'unpaid' && orderTotal > 0 && (
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 flex items-center gap-2">
                    <AlertCircle size={18} className="text-slate-500 flex-shrink-0" />
                    <span className="text-sm font-semibold text-slate-600">Sin pagos registrados</span>
                </div>
            )}

            {/* Timeline */}
            {payments.length > 0 && (
                <div className="space-y-2">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Transacciones</p>
                    <div className="space-y-2">
                        {payments.map((payment, idx) => (
                            <div key={idx} className="flex gap-3">
                                {/* Línea vertical */}
                                <div className="flex flex-col items-center">
                                    <div className="w-8 h-8 rounded-full bg-blue-100 border-2 border-blue-500 flex items-center justify-center flex-shrink-0">
                                        <CreditCard size={14} className="text-blue-600" />
                                    </div>
                                    {idx < payments.length - 1 && (
                                        <div className="w-0.5 h-8 bg-slate-200 mt-1"></div>
                                    )}
                                </div>

                                {/* Contenido */}
                                <div className="flex-1 pt-1">
                                    <div className="bg-white border border-slate-200 rounded-lg p-3">
                                        <div className="flex items-start justify-between mb-1">
                                            <div>
                                                <p className="text-sm font-semibold text-slate-800">
                                                    {payment.payment_method || 'Pago'}
                                                </p>
                                                <p className="text-xs text-slate-500">
                                                    {formatDateTime(payment.created_at || payment.payment_date)}
                                                </p>
                                            </div>
                                            <span className="text-sm font-bold text-emerald-600">
                                                {formatCurrency(parseFloat(payment.amount))}
                                            </span>
                                        </div>

                                        {payment.reference && (
                                            <p className="text-xs text-slate-600 font-mono">
                                                Ref: {payment.reference}
                                            </p>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Sin pagos */}
            {!payments.length && orderTotal > 0 && (
                <div className="text-center py-8">
                    <Clock className="mx-auto text-slate-300 mb-3" size={32} />
                    <p className="text-sm text-slate-500">Sin pagos registrados aún</p>
                    {onAddPayment && (
                        <button
                            onClick={onAddPayment}
                            className="mt-3 text-sm font-semibold text-blue-600 hover:text-blue-700"
                        >
                            Registrar primer pago →
                        </button>
                    )}
                </div>
            )}
        </div>
    );
};

export default PaymentTimeline;
