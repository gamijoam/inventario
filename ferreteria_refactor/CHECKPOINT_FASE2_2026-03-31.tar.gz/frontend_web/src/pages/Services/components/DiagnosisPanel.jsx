import React, { useState } from 'react';
import { FileText, Save, Edit2, X } from 'lucide-react';
import { toast } from 'react-hot-toast';

const DiagnosisPanel = ({ 
    diagnosis = '', 
    onSave = null,
    readOnly = false,
    compact = false
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editValue, setEditValue] = useState(diagnosis);
    const [saving, setSaving] = useState(false);

    const handleSave = async () => {
        if (!editValue.trim()) {
            toast.error('El diagnóstico no puede estar vacío');
            return;
        }

        setSaving(true);
        try {
            if (onSave) {
                await onSave(editValue);
                toast.success('Diagnóstico guardado');
                setIsEditing(false);
            }
        } catch (error) {
            toast.error('Error al guardar diagnóstico');
        } finally {
            setSaving(false);
        }
    };

    if (compact) {
        // Vista compacta para detalles
        return (
            <div className="bg-white border border-slate-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-slate-800 flex items-center gap-2">
                        <FileText size={16} className="text-yellow-600" />
                        Diagnóstico
                    </h4>
                    {!readOnly && diagnosis && (
                        <button
                            onClick={() => {
                                setEditValue(diagnosis);
                                setIsEditing(true);
                            }}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Editar"
                        >
                            <Edit2 size={14} />
                        </button>
                    )}
                </div>

                {!isEditing ? (
                    <p className="text-sm text-slate-700 leading-relaxed">
                        {diagnosis || <span className="text-slate-400 italic">Sin diagnóstico registrado</span>}
                    </p>
                ) : (
                    <div className="space-y-2">
                        <textarea
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-yellow-500 outline-none text-sm resize-none"
                            rows={4}
                            placeholder="Ingrese hallazgos técnicos..."
                        />
                        <div className="flex gap-2 justify-end">
                            <button
                                onClick={() => setIsEditing(false)}
                                className="px-3 py-1.5 text-sm text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                            >
                                Cancelar
                            </button>
                            <button
                                onClick={handleSave}
                                disabled={saving}
                                className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-1 transition-colors"
                            >
                                <Save size={14} /> Guardar
                            </button>
                        </div>
                    </div>
                )}
            </div>
        );
    }

    // Vista expandida para sidebar
    return (
        <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-2 border-yellow-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-yellow-900 flex items-center gap-2">
                    <FileText size={20} className="text-yellow-600" />
                    Diagnóstico
                </h3>
                {!readOnly && (
                    <button
                        onClick={() => {
                            setEditValue(diagnosis);
                            setIsEditing(!isEditing);
                        }}
                        className="p-2 text-yellow-600 hover:bg-yellow-200 rounded-lg transition-colors"
                        title={isEditing ? 'Cancelar' : 'Editar'}
                    >
                        {isEditing ? <X size={18} /> : <Edit2 size={18} />}
                    </button>
                )}
            </div>

            {!isEditing ? (
                <div className="space-y-2">
                    {diagnosis ? (
                        <>
                            <div className="bg-white rounded-lg p-4 border border-yellow-200">
                                <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">
                                    {diagnosis}
                                </p>
                            </div>
                            <p className="text-xs text-yellow-700 font-semibold">
                                📝 {diagnosis.length} caracteres
                            </p>
                        </>
                    ) : (
                        <div className="bg-white/60 rounded-lg p-6 text-center">
                            <FileText className="mx-auto text-yellow-300 mb-2" size={32} />
                            <p className="text-sm text-yellow-800">Sin diagnóstico registrado</p>
                            <p className="text-xs text-yellow-700 mt-1">
                                {!readOnly && 'Click en lápiz para agregar'}
                            </p>
                        </div>
                    )}
                </div>
            ) : (
                <div className="space-y-3">
                    <textarea
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        className="w-full p-3 border-2 border-yellow-300 rounded-lg focus:ring-2 focus:ring-yellow-500 outline-none text-sm resize-none font-mono"
                        rows={6}
                        placeholder="Escriba hallazgos técnicos, pruebas realizadas, etc..."
                    />

                    <div className="flex items-center justify-between">
                        <p className="text-xs text-yellow-700 font-semibold">
                            {editValue.length}/500 caracteres
                        </p>
                    </div>

                    <div className="flex gap-2 justify-end pt-2">
                        <button
                            onClick={() => setIsEditing(false)}
                            className="px-4 py-2 text-sm font-semibold text-yellow-700 hover:bg-yellow-200 rounded-lg transition-colors"
                        >
                            Cancelar
                        </button>
                        <button
                            onClick={handleSave}
                            disabled={saving || !editValue.trim()}
                            className="px-4 py-2 bg-yellow-600 text-white text-sm font-semibold rounded-lg hover:bg-yellow-700 disabled:opacity-50 flex items-center gap-2 transition-colors"
                        >
                            {saving ? '⏳ Guardando...' : (
                                <>
                                    <Save size={16} /> Guardar cambios
                                </>
                            )}
                        </button>
                    </div>
                </div>
            )}

            {!readOnly && !isEditing && (
                <p className="text-xs text-yellow-800 border-t border-yellow-200 pt-3 italic">
                    💡 Incluya: síntomas, pruebas realizadas, piezas reemplazadas, observaciones
                </p>
            )}
        </div>
    );
};

export default DiagnosisPanel;
