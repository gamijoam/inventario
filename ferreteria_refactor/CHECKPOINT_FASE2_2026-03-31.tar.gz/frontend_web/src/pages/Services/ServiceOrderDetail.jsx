import React, { useState, useEffect } from 'react';
import { ChevronLeft, Plus, Trash2, Download, MoreVertical } from 'lucide-react';
import apiClient from '../../config/axios';
import { toast } from 'react-hot-toast';
import DashboardLayout from '../../layouts/DashboardLayout';
import { useServiceOrder, useServiceCalculations } from './hooks/useServiceOrder';
import DiagnosisPanel from './components/DiagnosisPanel';
import PaymentTimeline from './components/PaymentTimeline';
import QuickItemForm from './components/QuickItemForm';
import printerService from '../../services/printerService';
import { useConfig } from '../../context/ConfigContext';

const STATUS_COLORS = {
    RECEIVED: 'bg-slate-100 text-slate-700',
    DIAGNOSING: 'bg-yellow-100 text-yellow-800',
    APPROVED: 'bg-blue-100 text-blue-800',
    IN_PROGRESS: 'bg-purple-100 text-purple-800',
    READY: 'bg-emerald-100 text-emerald-800',
    DELIVERED: 'bg-teal-100 text-teal-800',
    CANCELLED: 'bg-red-100 text-red-800',
};

const STATUS_LABELS = {
    RECEIVED: 'Recibido',
    DIAGNOSING: 'Diagnóstico',
    APPROVED: 'Aprobado',
    IN_PROGRESS: 'Reparando',
    READY: 'Listo',
    DELIVERED: 'Entregado',
    CANCELLED: 'Anulado',
};

const STATUS_FLOW = ['RECEIVED', 'DIAGNOSING', 'APPROVED', 'IN_PROGRESS', 'READY', 'DELIVERED'];

const ServiceOrderDetail = ({ orderId, onBack }) => {
    const { business } = useConfig();
    const paperWidth = business?.paper_width || '80';

    // Hooks
    const { order, loading, error, fetchOrder, updateStatus, addItem, deleteItem, addPayment } = useServiceOrder(orderId);
    const calculations = useServiceCalculations(order);

    // Local state
    const [showQuickForm, setShowQuickForm] = useState(false);
    const [technicians, setTechnicians] = useState([]);
    const [updatingStatus, setUpdatingStatus] = useState(false);
    const [showPaymentForm, setShowPaymentForm] = useState(false);
    const [paymentData, setPaymentData] = useState({ amount: 0, method: 'Efectivo', reference: '' });

    // Cargar datos
    useEffect(() => {
        if (orderId) {
            fetchOrder();
            // Cargar técnicos
            apiClient.get('/users/?role=technician').then(res => {
                setTechnicians(res.data || []);
            }).catch(err => console.error(err));
        }
    }, [orderId, fetchOrder]);

    if (loading) {
        return (
            <DashboardLayout>
                <div className="flex items-center justify-center h-screen">
                    <div className="text-center">
                        <div className="inline-block w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-4"></div>
                        <p className="text-slate-600">Cargando orden...</p>
                    </div>
                </div>
            </DashboardLayout>
        );
    }

    if (error || !order) {
        return (
            <DashboardLayout>
                <div className="flex items-center justify-center h-screen">
                    <div className="text-center">
                        <p className="text-red-600 font-semibold mb-4">{error || 'Orden no encontrada'}</p>
                        <button
                            onClick={onBack}
                            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                            Volver
                        </button>
                    </div>
                </div>
            </DashboardLayout>
        );
    }

    // Handlers
    const handleStatusChange = async (newStatus) => {
        setUpdatingStatus(true);
        try {
            await updateStatus(newStatus);
            toast.success(`Orden marcada como ${STATUS_LABELS[newStatus]}`);
        } catch (err) {
            toast.error('Error al cambiar estado');
        } finally {
            setUpdatingStatus(false);
        }
    };

    const handleAddItem = async (itemData) => {
        try {
            await addItem(itemData);
            toast.success('Ítem agregado');
            setShowQuickForm(false);
        } catch (err) {
            toast.error(err.response?.data?.detail || 'Error al agregar ítem');
        }
    };

    const handleDeleteItem = async (itemId) => {
        if (window.confirm('¿Eliminar este ítem?')) {
            try {
                await deleteItem(itemId);
                toast.success('Ítem eliminado');
            } catch (err) {
                toast.error('Error al eliminar ítem');
            }
        }
    };

    const handleAddPayment = async () => {
        if (paymentData.amount <= 0) {
            toast.error('Ingrese monto válido');
            return;
        }

        try {
            await addPayment({
                amount: paymentData.amount,
                payment_method: paymentData.method,
                reference: paymentData.reference || null,
            });
            toast.success('Pago registrado');
            setShowPaymentForm(false);
            setPaymentData({ amount: 0, method: 'Efectivo', reference: '' });
        } catch (err) {
            toast.error('Error al registrar pago');
        }
    };

    const handlePrint = async () => {
        try {
            const res = await apiClient.get(`/services/orders/${orderId}/print/thermal?width=${paperWidth}`);
            await printerService.printRaw(res.data);
            toast.success('Enviado a impresora');
        } catch (err) {
            toast.error('Error al imprimir');
        }
    };

    const nextStatus = STATUS_FLOW[STATUS_FLOW.indexOf(order.status) + 1] || order.status;

    return (
        <DashboardLayout>
            <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
                <div className="max-w-7xl mx-auto">
                    {/* Header */}
                    <div className="flex items-center justify-between mb-6">
                        <button
                            onClick={onBack}
                            className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:bg-white rounded-lg transition-colors"
                        >
                            <ChevronLeft size={20} /> Volver
                        </button>
                        <div className="flex gap-2">
                            <button
                                onClick={handlePrint}
                                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                            >
                                🖨️ Imprimir
                            </button>
                            <button
                                className="p-2 text-slate-600 hover:bg-white rounded-lg transition-colors"
                            >
                                <MoreVertical size={20} />
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Main Column */}
                        <div className="lg:col-span-2 space-y-6">
                            {/* Ticket Info */}
                            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-4">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h1 className="text-3xl font-bold text-slate-900 font-mono">{order.ticket_number}</h1>
                                        <p className="text-slate-600 mt-1">
                                            Creada {new Date(order.created_at).toLocaleDateString()}
                                        </p>
                                    </div>
                                    <span className={`px-4 py-2 rounded-lg text-sm font-bold uppercase tracking-wider ${STATUS_COLORS[order.status]}`}>
                                        {STATUS_LABELS[order.status]}
                                    </span>
                                </div>

                                {/* Cliente y Equipo */}
                                <div className="grid grid-cols-2 gap-4 border-t border-slate-200 pt-4">
                                    <div>
                                        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Cliente</p>
                                        <p className="text-lg font-bold text-slate-800">{order.customer?.name}</p>
                                        <p className="text-sm text-slate-600">{order.customer?.phone}</p>
                                    </div>
                                    <div>
                                        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Equipo</p>
                                        <p className="text-lg font-bold text-slate-800">{order.brand} {order.model}</p>
                                        {order.serial_imei && (
                                            <p className="text-sm text-slate-600 font-mono">{order.serial_imei}</p>
                                        )}
                                    </div>
                                </div>

                                {/* Falla reportada */}
                                {order.problem_description && (
                                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 border-l-4 border-l-orange-500">
                                        <p className="text-xs font-semibold text-slate-500 uppercase mb-1">⚠️ Falla Reportada</p>
                                        <p className="text-slate-700">{order.problem_description}</p>
                                    </div>
                                )}
                            </div>

                            {/* Status Stepper */}
                            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                                <h3 className="font-bold text-slate-800 mb-4">Estado del Trabajo</h3>
                                <div className="space-y-3">
                                    {STATUS_FLOW.map((status, idx) => (
                                        <div key={status} className="flex items-start gap-3">
                                            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                                                STATUS_FLOW.indexOf(order.status) >= idx
                                                    ? STATUS_FLOW.indexOf(order.status) === idx
                                                        ? 'bg-blue-600 text-white'
                                                        : 'bg-emerald-100 text-emerald-700'
                                                    : 'bg-slate-200 text-slate-400'
                                            }`}>
                                                {STATUS_FLOW.indexOf(order.status) > idx ? '✓' : idx + 1}
                                            </div>
                                            <div className="flex-1">
                                                <p className={`font-semibold ${
                                                    STATUS_FLOW.indexOf(order.status) === idx ? 'text-blue-600' : 'text-slate-700'
                                                }`}>
                                                    {STATUS_LABELS[status]}
                                                </p>
                                            </div>
                                            {STATUS_FLOW.indexOf(order.status) === idx && (
                                                <button
                                                    onClick={() => handleStatusChange(nextStatus)}
                                                    disabled={updatingStatus}
                                                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:opacity-50"
                                                >
                                                    Avanzar
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Items */}
                            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                                <div className="flex items-center justify-between mb-4">
                                    <h3 className="font-bold text-slate-800">Repuestos y Mano de Obra</h3>
                                    <button
                                        onClick={() => setShowQuickForm(true)}
                                        className="px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 flex items-center gap-2 transition-colors"
                                    >
                                        <Plus size={16} /> Agregar
                                    </button>
                                </div>

                                {order.details && order.details.length > 0 ? (
                                    <div className="space-y-2">
                                        {order.details.map(item => (
                                            <div key={item.id} className="bg-slate-50 rounded-lg p-4 border border-slate-200 flex items-center justify-between">
                                                <div className="flex-1">
                                                    <p className="font-semibold text-slate-800">{item.description}</p>
                                                    <p className="text-sm text-slate-600">
                                                        {item.quantity} × ${item.unit_price} = ${(item.quantity * item.unit_price).toFixed(2)}
                                                    </p>
                                                </div>
                                                <button
                                                    onClick={() => handleDeleteItem(item.id)}
                                                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                                >
                                                    <Trash2 size={18} />
                                                </button>
                                            </div>
                                        ))}
                                        <div className="bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg p-4 border border-slate-200 mt-4">
                                            <div className="flex items-center justify-between">
                                                <span className="font-bold text-slate-700">Total:</span>
                                                <span className="text-2xl font-bold text-slate-800">${calculations.orderTotal.toFixed(2)}</span>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-center py-8 text-slate-500">
                                        <p>Sin items agregados</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Sidebar */}
                        <div className="lg:col-span-1 space-y-6">
                            {/* Diagnosis */}
                            <DiagnosisPanel
                                diagnosis={order.diagnosis_notes || ''}
                                onSave={async (notes) => {
                                    try {
                                        await updateStatus(order.status, notes);
                                    } catch (err) {
                                        throw err;
                                    }
                                }}
                                compact={false}
                            />

                            {/* Payments */}
                            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                                <PaymentTimeline
                                    payments={order.payments || []}
                                    orderTotal={calculations.orderTotal}
                                    onAddPayment={() => setShowPaymentForm(true)}
                                />
                            </div>

                            {/* Payment Form */}
                            {showPaymentForm && (
                                <div className="bg-emerald-50 border-2 border-emerald-200 rounded-lg p-4 space-y-3">
                                    <div>
                                        <label className="text-sm font-semibold text-slate-700">Monto</label>
                                        <input
                                            type="number"
                                            step="0.01"
                                            value={paymentData.amount}
                                            onChange={(e) => setPaymentData(prev => ({ ...prev, amount: parseFloat(e.target.value) }))}
                                            className="w-full mt-1 px-3 py-2 border border-emerald-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                                            placeholder="0.00"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-sm font-semibold text-slate-700">Método</label>
                                        <select
                                            value={paymentData.method}
                                            onChange={(e) => setPaymentData(prev => ({ ...prev, method: e.target.value }))}
                                            className="w-full mt-1 px-3 py-2 border border-emerald-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                                        >
                                            <option>Efectivo</option>
                                            <option>Pago Móvil</option>
                                            <option>Transferencia</option>
                                            <option>Tarjeta</option>
                                        </select>
                                    </div>
                                    <div className="flex gap-2">
                                        <button
                                            onClick={() => setShowPaymentForm(false)}
                                            className="flex-1 px-3 py-2 text-sm text-emerald-700 hover:bg-emerald-100 rounded-lg transition-colors"
                                        >
                                            Cancelar
                                        </button>
                                        <button
                                            onClick={handleAddPayment}
                                            className="flex-1 px-3 py-2 bg-emerald-600 text-white text-sm font-semibold rounded-lg hover:bg-emerald-700 transition-colors"
                                        >
                                            Guardar
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Quick Item Form Modal */}
            <QuickItemForm
                isOpen={showQuickForm}
                onClose={() => setShowQuickForm(false)}
                onSubmit={handleAddItem}
                technicians={technicians}
            />
        </DashboardLayout>
    );
};

export default ServiceOrderDetail;
